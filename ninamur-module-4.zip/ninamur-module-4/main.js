function toggleDropdown() {
    document.querySelector(".dropdown-options").style.display = "block";
  }

  function selectOption(value) {
    document.querySelector(".selected-option").innerHTML = value;
    document.querySelector(".dropdown-options").style.display = "none";
  }
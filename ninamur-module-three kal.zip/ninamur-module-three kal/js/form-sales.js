function openTab(event) {
    // Hide all tab content
    document.querySelectorAll('.fiscal-tab-section .tab-content').forEach(tab => {
        tab.classList.remove('active');
    });

    // Remove active class from all buttons
    document.querySelectorAll('.fiscal-tab-section .tab-button').forEach(button => {
        button.classList.remove('active');
    });

    // Show the selected tab content
    const tabId = event.target.getAttribute("idToTarget");
    console.log(tabId)
    document.getElementById(tabId).classList.add('active');

    // Highlight the clicked tab button
    event.currentTarget.classList.add('active');
}


function openEyeTab(event) {
    // Hide all tab content
    document.querySelectorAll('.eyeware .tab-content').forEach(tab => {
        tab.classList.remove('active');
    });

    // Remove active class from all buttons
    document.querySelectorAll('.eyeware .tab-button').forEach(button => {
        button.classList.remove('active');
    });
    const tabId = event.target.getAttribute("idToTarget");
    // Show the selected tab content
    document.getElementById(tabId).classList.add('active');

    // Highlight the clicked tab button
    event.currentTarget.classList.add('active');
}

function openAaTab(event) {
    // Hide all tab content
    document.querySelectorAll('.aa-tab-section .tab-content').forEach(tab => {
        tab.classList.remove('active');
    });

    // Remove active class from all buttons
    document.querySelectorAll('.aa-tab-section .tab-button').forEach(button => {
        button.classList.remove('active');
    });
    const tabId = event.target.getAttribute("idToTarget");
    if(tabId==="in-partial"){
addBottomPadding()
    }else{
removeBottomPadding()
    }
    // Show the selected tab content
    document.getElementById(tabId).classList.add('active');

    // Highlight the clicked tab button
    event.currentTarget.classList.add('active');
}

function addBottomPadding(){
    document.querySelector(".aa-tab-section #in-partial.tab-content").style.padding ="0";
    // .aa-tab-section #in-partial.tab-content
    document.querySelector(".aa .tab-container").style.borderRadius="10px"
}
function removeBottomPadding(){

    // .aa-tab-section #in-partial.tab-content
    document.querySelector(".aa .tab-container").style.borderRadius="10px 10px 0 0"
}


// date picker


        // Select all date inputs and custom icons
        // const dateInputs = document.querySelectorAll('#dateInput'); 
        // const customIcons = document.querySelectorAll('#customIcon'); 
        
        
        // customIcons.forEach((customIcon, index) => {
        //     customIcon.addEventListener('click', () => {
                
        //         dateInputs[index].showPicker();
        //     });
        // });
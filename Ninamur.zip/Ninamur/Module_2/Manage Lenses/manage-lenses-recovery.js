document.getElementById("closeSidebar").addEventListener("click", function () {
  document.getElementById("sidebar").classList.add("collapsed");
  console.log("toggle btn ", document.getElementById("toggleBtnOpen"));
  document.getElementById("toggleBtnOpen").classList.remove("d-none");
});

document.getElementById("openSidebar").addEventListener("click", function () {
  document.getElementById("sidebar").classList.remove("collapsed");
  document.getElementById("toggleBtnOpen").classList.add("d-none");
});

// --------timeline js---------

function toggleSubMenu(id, element) {
  document.querySelectorAll(".submenu").forEach((submenu) => {
    if (submenu.id !== id) {
      submenu.style.display = "none";
    }
  });

  document.querySelectorAll(".menu-item").forEach((menuItem) => {
    if (menuItem !== element) {
      menuItem.classList.remove("active");
    }
  });

  let submenu = document.getElementById(id);
  submenu.style.display = submenu.style.display === "block" ? "none" : "block";
  element.classList.toggle("active");
}

function activateTimeline(element) {
  document
    .querySelectorAll(".timeline li")
    .forEach((el) => el.classList.remove("active"));
  element.classList.add("active");
}

// footer ---------

document.addEventListener("DOMContentLoaded", function () {
  const sidebar = document.getElementById("dynamicHeight");
  const footer = document.getElementById("footer");

  function checkFooterVisibility() {
    const footerRect = footer.getBoundingClientRect();
    if (footerRect.top <= window.innerHeight) {
      sidebar.classList.add("sidebar-reduced");
    } else {
      sidebar.classList.remove("sidebar-reduced");
    }
  }

  window.addEventListener("scroll", checkFooterVisibility);
});

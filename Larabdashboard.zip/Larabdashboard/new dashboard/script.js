$(document).ready(function () {
    $('.tab-button').click(function () {
        $('.tab-button').removeClass('active');
        $(this).addClass('active');
        $('.tab-content').removeClass('active');
        $('#' + $(this).data('tab')).addClass('active');
    });

    $(document).on('click', '.delete-button', function () {
        $(this).closest('tr').remove();
    });

    $('.add-row').click(function () {
        const newRow = `<tr>
            <td class="td"><input type="date" class="secon-cal"></td>
            <td class="td"><input type="text"></td>
            <td class="td"><input type="number"></td>
            <td class="td"><input type="date" class="secon-cal"></td>
            <td class="td"><input type="number"></td>
            <td class="td">0</td>
            <td class="td"><span class="delete-button"><img src="icons/deletenew.png" alt="Delete"></span></td>
        </tr>`;
        $(this).siblings('table').find('.table-body').append(newRow);
    });

    // $('.add-composition').click(function () {
    //     const newCompositionRow = `<tr>
    //         <td class="td">SG003</td>
    //         <td class="td"><input type="text" value="New Item"></td>
    //         <td class="td"><input type="number" value="0"></td>
    //         <td class="td"><input type="number" value="0"></td>
    //         <td class="td"><input type="text"></td>
    //         <td class="td"><input type="number" value="0"></td>
    //         <td class="td"><input type="number" value="0"></td>
    //         <td class="td"><input type="number" value="0"></td>
    //         <td class="td"><span class="delete-button"><img src="icons/deletenew.png" alt="Delete"></span></td>
    //     </tr>`;
    //     $(this).siblings('table').find('.composition-body').append(newCompositionRow);
    // });
});



//  
// 
// 
// 
// 
// 


const hitEvent = document.querySelector('.hitEvent');
const srjDiv = document.querySelector('.sr-add-data-search-bar-and-list');
hitEvent.addEventListener('click', () => {
  if (srjDiv.style.display === 'none' || srjDiv.style.display === '') {
    srjDiv.style.display = 'block'; 
  } else {
    srjDiv.style.display = 'none';
  }
});




// delete composition code
// Use jQuery to handle the click event for the delete icon
$(document).on('click', '.delete-button-composition', function() {
    // Find the closest 'tr' and remove it
    $(this).closest('tr').remove();
  });
  

// search filter
  document.addEventListener("DOMContentLoaded", function () {
    const searchInput = document.querySelector(".sr-search-bar-input input");
    const listItems = Array.from(document.querySelectorAll(".sr-add-data-list-items ul li"));
    const listContainer = document.querySelector(".sr-add-data-list-items ul");

    searchInput.addEventListener("input", function () {
        const query = searchInput.value.trim().toLowerCase();
        
        if (query === "") {
            listContainer.innerHTML = "";
            listItems.forEach(item => listContainer.appendChild(item));
            return;
        }

        const matchedItems = [];
        const nonMatchedItems = [];

        listItems.forEach(item => {
            const text = item.textContent.toLowerCase();
            if (text.includes(query)) {
                matchedItems.push(item);
            } else {
                nonMatchedItems.push(item);
            }
        });

        listContainer.innerHTML = "";
        matchedItems.forEach(item => listContainer.appendChild(item));
        nonMatchedItems.forEach(item => listContainer.appendChild(item));
    });
});
